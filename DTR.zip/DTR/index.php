<html>
<title> Employees Attendance Monitoring System </title>
 
 
    <script src="js/bootstrap.min.js"></script>
    <link href="js/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
      /* Override some defaults */
      html, body {
        background-color: #eee;
      }
      body {
        padding-top: 40px; 
      }
      .container {
        width: 700px;
      }

      /* The white background content wrapper */
      .container > .content {
        //background-color: #fff;
		background-color: lightgreen;
        padding: 20px;
        margin: 0 -20px; 
        -webkit-border-radius: 10px 10px 10px 10px;
           -moz-border-radius: 10px 10px 10px 10px;
                border-radius: 10px 10px 10px 10px;
        -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.15);
           -moz-box-shadow: 0 1px 2px rgba(0,0,0,.15);
                box-shadow: 0 1px 2px rgba(0,0,0,.15);
      }

	  .login-form {
		margin-left: 65px;
	  }
	
	  legend {
		margin-right: -50px;
		font-weight: bold;
	  	color: #404040;
	  }

    </style>
	<body>


	
	
	
	<div class="container">
    <div class="content">
	<div class="row">
        <div class="login-form"> 
		<h3> Employee's Attendance Monitoring System </h3>
		
 <a href="check_in.php"><button class="btn btn-info"  name='submit' 
 title="Click here to check in in the system."  />
 Check In</button></a> 
 
 
 <a href="Admin_login.php"><button class="btn btn-info"  name='submit' 
 title="Click here to check in in the system."  />
 Admin page</button></a> 
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 </div> </div></div> </div>
 </body>
 </html>