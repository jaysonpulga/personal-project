-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2016 at 11:10 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dtr`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE IF NOT EXISTS `admin_user` (
`id` int(11) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `Fullname` varchar(150) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `username`, `password`, `Fullname`) VALUES
(1, 'admin', 'admin', 'Jayson Pulga'),
(2, 'user', 'user', 'dodie');

-- --------------------------------------------------------

--
-- Table structure for table `check_out`
--

CREATE TABLE IF NOT EXISTS `check_out` (
`id` int(11) NOT NULL,
  `Id_Number` int(15) NOT NULL,
  `date2` date NOT NULL,
  `check_out` time NOT NULL,
  `checkin_id` int(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `check_out`
--

INSERT INTO `check_out` (`id`, `Id_Number`, `date2`, `check_out`, `checkin_id`) VALUES
(1, 123, '2016-11-15', '00:25:06', 1),
(2, 123, '2016-11-15', '00:30:03', 2),
(3, 123, '2016-11-15', '00:44:07', 3),
(4, 123, '2016-11-15', '00:46:51', 4),
(5, 123, '2016-11-15', '00:50:46', 5),
(6, 123, '2016-11-15', '00:56:48', 6),
(7, 123, '2016-11-15', '18:35:09', 7),
(8, 123, '2016-11-15', '22:55:51', 8),
(9, 123, '2016-11-16', '01:38:45', 0),
(10, 12345, '2016-11-16', '01:43:36', 10),
(11, 12345, '2016-11-16', '01:47:24', 11);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
`id` int(11) NOT NULL,
  `Id_Number` int(12) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `First_Name` varchar(100) NOT NULL,
  `Middle_Name` varchar(100) NOT NULL,
  `Last_Name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `Id_Number`, `Password`, `First_Name`, `Middle_Name`, `Last_Name`) VALUES
(1, 12345, 'admin', 'Dodie', '', 'Delosreyes'),
(2, 123, '123', 'Jayson', 'Gatungay', 'Pulga');

-- --------------------------------------------------------

--
-- Table structure for table `time`
--

CREATE TABLE IF NOT EXISTS `time` (
`id` int(11) NOT NULL,
  `Id_Number` int(12) NOT NULL,
  `date1` date NOT NULL,
  `check_in` time NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `time`
--

INSERT INTO `time` (`id`, `Id_Number`, `date1`, `check_in`) VALUES
(1, 123, '2016-11-15', '00:24:54'),
(2, 123, '2016-11-15', '00:26:01'),
(3, 123, '2016-11-15', '00:32:44'),
(4, 123, '2016-11-15', '00:46:40'),
(5, 123, '2016-11-15', '00:47:47'),
(6, 123, '2016-11-15', '00:51:02'),
(7, 123, '2016-11-15', '18:34:58'),
(8, 123, '2016-11-15', '22:55:18'),
(9, 123, '2016-11-16', '01:38:34'),
(10, 12345, '2016-11-16', '01:43:05'),
(11, 12345, '2016-11-16', '01:47:08'),
(12, 123, '2016-11-16', '09:10:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `check_out`
--
ALTER TABLE `check_out`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `time`
--
ALTER TABLE `time`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_user`
--
ALTER TABLE `admin_user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `check_out`
--
ALTER TABLE `check_out`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `time`
--
ALTER TABLE `time`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
