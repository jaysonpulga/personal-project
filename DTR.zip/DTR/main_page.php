<?php
if (empty($_COOKIE['Id_Number'])){
   header("Location:check_in.php");
}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Login Security</title>
    <meta name="description" content="">
    <meta name="author" content="">

	<script src="js/jquery-1.8.3.js"></script>
	<script src="js/jquery-ui-1.9.2.custom.js"></script>
	<script src="js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="js/jquery.alerts.js" type="text/javascript"></script>
	
    <script src="js/bootstrap.min.js"></script>
    <link href="js/bootstrap.min.css" rel="stylesheet">
	<link href="css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />

</head>
<body>



  <div style="margin:0px auto;width:900px;background:#fff;padding:20px;height:615px">
	
	<div style="float:left">
	<H1>WELCOME: <span><?php echo $_COOKIE['fullname']; ?><span></h1>	
	</div>
	
	<div style="float:right">
	<a onclick="logout()">[Log-out]</a>	
	</div>
	<div style="clear:both;padding-top:3px">
	<p>Date Today:<?php echo date('Y/m/d') ?></p>
	<p>you are Log-in at:<span><?php echo $_COOKIE['Timein']; ?></span></p>
	<hr></hr>
	</div>	
		
	
	
</div>

  
  </body>
</html>


<script>

function logout()
{
	window.location = "check_out.php";
}



</script>



<style type="text/css">
      /* Override some defaults */
      html, body {
        background-color: #eaf3f7;
      }
      body {
        margin:0px; 
      }
     
	p{
		font-size:20px;!important
	}

}			
</style>
