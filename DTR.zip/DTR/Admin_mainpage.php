<?php
if (empty($_COOKIE['username'] )){
   header("Location:index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Admin Panel</title>
    <meta name="description" content="">
    <meta name="author" content="">

	<script src="js/jquery-1.8.3.js"></script>
	<script src="js/jquery-ui-1.9.2.custom.js"></script>
	<script src="js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="js/jquery.alerts.js" type="text/javascript"></script>
	
    <script src="js/bootstrap.min.js"></script>
    <link href="js/bootstrap.min.css" rel="stylesheet">
	<link href="css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />

</head>
<body>

<div style="margin:0px auto;width:900px;background:#fff;padding:20px;height:615px">
	
	<div style="float:left">
	<H1>WELCOME: <span><?php echo $_COOKIE['Fullname']  ?><span></h1>	
	</div>
	
	<div style="float:right">
	<a onclick="logout()">[Log-out]</a>	
	</div>
	<div style="clear:both;padding-top:3px">
	<p>Date Today:<?php echo date('Y/m/d') ?></p>
	<hr></hr>
	</div>	
	
	
	
	<div style="background:#fff;margin-top:15px;min-height:430px;padding:3px;text-align:left;">
	<div style="margin-left:10px;margin-right:10px;margin-top:20px;">
	
		

		<button id="btn-add-new-user" class="btn btn-success btn-sm pull-right" style="margin-right:35px;margin-bottom:3px;">
			<span style="margin-right:5px;" class="glyphicon glyphicon-plus"></span>Add New Employee
		</button>
		
	

	<table id="sample" class="table table-striped">
	
	<thead>
		<th>FirstName</th>
		<th>Middle_Name</th>
		<th>Last Name</th>
		<th>Actions</th>		
	</thead>
	<tbody id="alldata"></tbody>
	
	</table>
	</div>
	</div>
		
	
	
</div>





  
  </body>
</html>


<script>

function logout()
{
	
	jConfirm('Are you sure you wan to Log Out?','Confirmation Dialog',function(e){
			
			if(e){
			
				
		
	
			$.ajax({
				url: 'main_function.php',
				data: {'request':'ajax','action':'check_logout_admin'},
				beforeSend: function(){		
				}, 
				success : function(reply){
					
				
					if(reply == "logout!"){
						
					
						alert("Thank You");
						
						
						window.location = "index.php";
					} else {
						jAlert(reply,"Alert Dialog");
					} 
					
				}, 
				error: function(xhr, status, error) {
					console.log(xhr.responseText+" "+status+" "+error )
				}
			});

		}
	
	});	
}



$(document).ready(function(){
	show_employee();
});


function show_employee()
{	

	var container = $("#sample > tbody");
	var count = 0;
	
	$.ajax({
	
			url: 'main_function.php',
			data: {'request':'ajax','action':'fetch_allemployee'},			
			dataType:'json',
					
			beforeSend: function(){
						
			},
			success: function(reply){
	
				if(reply.length > 0){
					container.empty();
				$.each(reply, function(i,res){
						count++;
						container.append("<tr><td>"+res.First_Name+"</td><td>"+res.Middle_Name+"</td><td>"+res.Last_Name+"</td><td><a href='view.php?Id_Number="+res.Id_Number+"' target='_blank'>View Record</a></td></tr>");												
						
						
				});
				
				
				
				}
		
			} 
	}); 	
}
</script>



<style type="text/css">
      /* Override some defaults */
      html, body {
        background-color: #eaf3f7;
      }
      body {
        margin:0px; 
      }
     
	p{
		font-size:20px;!important
	}

}			
</style>
