<html>
<title> View Student Attendance Record </title>
<body>
<?php
include('dbcon.php');
?>
<?php ob_start(); ?>
<?php
$id=$_GET['Id_Number'];
?>

<script language="javascript">
function Clickheretoprint()
{ 
		var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
		    disp_setting+="scrollbars=yes,width=1000, height=1000, left=100, top=15"; 
		var content_vlue = document.getElementById("print_content").innerHTML; 
		
		var docprint=window.open("","",disp_setting); 
			docprint.document.open(); 
			docprint.document.write('<html><head><title>Student Profile System Print Preview</title>'); 
			docprint.document.write('</head><body onLoad="self.print()">');          
			docprint.document.write(content_vlue);     
            docprint.document.write('<p align=center><font face=arial  size=3 > Created By: ME </p></font>'); 			
			docprint.document.write('</body></html>'); 
			docprint.document.close(); 
			docprint.focus(); 
}
</script>
<br>
<div class="style3" id="print_content">
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td align="center"><h1><font color='black' face="Arial">EMPLOYEE'S ATTENDANCE MONITORING SYSTEM</font></h1></td>
  </tr>
  

  
</table>
<br><br>

<table width="70%" bordercolor="white"  border="1" align="center" cellpadding="2" cellspacing="0">

 <?php
		$sql= "SELECT *  FROM tbl_employee  WHERE Id_Number ='".$id."' ";
			  
		$result = mysql_query($sql);
			
		while ($row=mysql_fetch_array($result))
		{

			
			$ID=$row["Id_Number"];
			$lname=$row["Last_Name"];
			$fname=$row["First_Name"];
			$mname=$row["Middle_Name"];
			
?>



<tr> 
    <td width="2%">&nbsp;</td>
    <td width="20%"><font size="3" face="Arial"><b>Employee's ID Number</b></font></td>
    <td width="2%" align="center">:</td>
    <td width="46%"><font size="3" face="Arial"><?php echo"$ID"; ?></font></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><font size="3" face="Arial"><b>Last Name</b></font></td>
    <td align="center">:</td>
    <td><font size="3" face="Arial"><?php echo"$lname"; ?></font></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><font size="3" face="Arial"><b>First Name</b></font></td>
    <td align="center">:</td>
    <td><font size="3" face="Arial"><?php echo"$fname"; ?></font></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><font size="3" face="Arial"><b>Middle Name</b></font></td>
    <td align="center">:</td>
    <td><font size="3" face="Arial"><?php echo"$mname"; ?></font></td>
  </tr> 
  

</table>

  <?php
  
 
  
  } 
?>


<br>
 <?php
		$sql= "SELECT t1.*,t2.* FROM time t1, check_out t2  WHERE t1.Id_Number ='".$id."' AND  t1.id = t2.checkin_id ";
			  
		$result = mysql_query($sql);
			
		while ($row=mysql_fetch_array($result))
		{
			
		echo '<table width="70%" bordercolor="white" bgcolor="silver" border="1" align="center" cellpadding="2" cellspacing="0">';
			
			
			/* $ID=$row["Id_Number"];
			$lname=$row["Last_Name"];
			$fname=$row["First_Name"];
			$mname=$row["Middle_Name"] */;
			
			
			
			$date=$row["date1"];
			$date=$row["date2"];
			$check_in=$row["check_in"];
			$check_out=$row["check_out"];
		
		$start_date = new DateTime($check_in,new DateTimeZone('Asia/Manila'));
        $end_date = new DateTime($check_out, new DateTimeZone('Asia/Manila'));

		
		
		$interval = $start_date->diff($end_date);	
		$hours   = $interval->format('%h');
		$minutes = $interval->format('%i');
        $seconds = $interval->format('%s');
		
		$total_time = $hours .":".$minutes.":".$seconds;
?>
  
  <tr> 
    <td>&nbsp;</td>
    <td><font size="3" face="Arial"><b>Date</b></font></td>
    <td align="center">:</td>
    <td><font size="3" face="Arial"><?php echo"$date"; ?></font></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><font size="3" face="Arial"><b>Check In</b></font></td>
    <td align="center">:</td>
    <td><font size="3" face="Arial"><?php echo"$check_in"; ?></font></td>
  </tr>
  <tr> 
  <td>&nbsp;</td>
    <td><font size="3" face="Arial"><b>Check Out</b></font></td>
    <td align="center">:</td>
    <td><font size="3" face="Arial"><?php echo"$check_out"; ?></font></td>
  </tr>
   <tr> 
   <td>&nbsp;</td>
    <td><font size="3" face="Arial"><b>Total Time</b></font></td>
    <td align="center">:</td>
    <td colspan="3"><font size="3" face="Arial"><?php echo"$total_time"; ?></font></td>
  </tr>
   
  <?php
  echo "</table>";
  
  echo "<br>";
  
  } 
?>

  </div>
   <div align="left"> <li> <font face='arial'  size='4'><b> PRINT HERE </b> </font></li> 
   <a href="javascript:Clickheretoprint()" title="Click here to print report.">
   <img src="css/print.png" Style="height:30px; witdh:30px;" /></a> </div>
</body>
</html>
