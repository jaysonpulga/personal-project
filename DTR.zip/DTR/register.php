
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Register User</title>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="js/bootstrap.min.css" rel="stylesheet" media="screen">
    <style type="text/css">
        body { background: url(assets/bglight.png); }
        .hero-unit { background-color: #fff; }
        .center { display: block; margin: 0 auto; }
    </style>
</head>

<body>

<div class="container hero-unit">
    <h3>Register User</h3>
    <form action="register.php" method="post"> 
        <label>Username:</label> 
        <input type="text" name="username" value="" /> 
        <label>Email: </label> 
        <input type="text" name="email" value="" /> 
        <label>Password:</label> 
        <input type="password" name="password" value="" /> <br /><br />
         <button class="btn btn-info"  type="submit" title="Click here to save record in the database.">
			  Save Record</button>        
		  <button class="btn btn-info"  type="submit" name="return_me" title="Click here to return to login page.">
			  Return</button>        
			  
		</form>
</div>
 <?php
     if  (isset($_REQUEST['return_me'])) {
	   	header("location: index.php");
		}
	   
	?>  
	 
</body>
</html>