<?php
include 'Crud.php';
$object = new Crud();
$table = 'users';

Class animal
{     
	function getName()
	{
		 $record_per_page = 5;
		  $page = '';
		  $defaultval  = 'DESC';

		  if(isset($_POST["page"]))
		  {
		   $page = $_POST["page"];
		  }
		  else
		  {
		   $page = 1;
		  }
		  $start_from = ($page - 1) * $record_per_page;
		  
		  
		  if(!empty($_POST["val"]))
		  {
		   $val = $_POST["val"];

		  }
		  else
		  {
		   $val = "DESC";
		  }
		  
		  

		  echo $object->get_data_in_table("SELECT * FROM users ORDER BY id $val LIMIT $start_from, $record_per_page");
		  echo '<br /><div align="center">';
		  echo $object->make_pagination_link("SELECT * FROM users ORDER by id", $record_per_page, $page);
		  echo '</div><br />';
	}

	
}
?>


<?php


if(isset($_POST["action"]))
{
	if($_POST["action"] == "Load")
	 {
		$myAnimal = new animal();
	    $result = $myAnimal->getName();
	 }
	
	
}

?>