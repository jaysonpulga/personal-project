<?php
//index.php
/* include 'Crud.php';
$object = new Crud(); */
?>
<html>
 <head>
  <title>Exam</title>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.5/sweetalert2.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.5/sweetalert2.js"></script>

<style>

.swal2-modal {
	
 border-radius: 0px !important;
}

.swal2-modal .swal2-title {

font-size: 18px !important;
  
}
</style>

  
  
  <style>
   body
   {
    margin:0;
    padding:0;
    background-color:#f1f1f1;
   }
   .box
   {
    width:1100px;
    padding:20px;
    background-color:#fff;
    border:1px solid #ccc;
    border-radius:1px;
    margin-top:2px;
   }
   
   .active
   {
	   color:#fff;
	   background-color:gray;
   }

   
  </style>
 </head>
 <body>
  <div class="container box">
   <br/>
   <br/>
   <div class='row'>
   
	   <div class="col-md-8" >
			<button id='add_new_button' onclick="add_new_data()" class="btn btn-success btn-sm" >
				<span  class="glyphicon glyphicon-plus m-right"></span>Add New Data
			</button>
		</div>
	   
	   
	   <div class="col-md-4">
			<input type="text" name="search" id="search" placeholder="Search by Name or Lastname" class="form-control" />
	   </div>
	   
	   
	   
   </div>
    <br />
   <div class='row'>
		<div class="col-md-2">
			 <div class="form-group">
				<select class="form-control" onchange="getUsers(this.value)">
				 <option value="DESC">Descending</option>
				 <option value="ASC">Ascending</option>
				  
				</select>
			</div>
	    </div>
	</div>
   
   <br/>

   
   <div class='row'>
	  <div class="col-md-12" >
			<div id="user_table" class="table-responsive"></div>
	  </div>
   </div>
   
   
  
  </div>
 </body>
</html>


<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form_data" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Information</h3>
            </div>
			
            <div class="modal-body form">
				<form id="user_form" class="form-horizontal" >
                    <input name="user_id" id="user_id" type="hidden">
                    <div class="form-body">
							
							
							
							<div class="form-group">
								<label class="control-label col-md-3">First Name:</label>
								<div class="col-md-9">
									<input name="first_name"  id="first_name" class="form-control" type="text">
									<span class="validation1" id='val_title' ></span>
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-md-3">Last Name:</label>
								<div class="col-md-9">
									<input name="last_name" id='last_name' class="form-control" type="text">
									<span class="validation1" id='val_author' ></span>
								</div>
							</div>
							
                    </div>
                </form>
            </div>
			
            <div class="modal-footer">
				<button type="button" id="btnSave" onclick="saveData()" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
			
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">
$(document).ready(function(){

  load_data(); 
  
});

function load_data(page,val='')
{
	var action = "Load";
	
	$.ajax({
		url:"action.php",
		type:"POST",
		data:{action:action, page:page,val:val},
		success:function(data)
		{
		 
		 //alert(data);
		 
		 $('#user_table').html(data);
		}
	});
	
}
 



function getUsers(val){
	
	
	load_data(page=1,val);
	
	//alert(type + ' ' + val);
	
    /* $.ajax({
        type: 'POST',
        url: 'getData.php',
        data: 'type='+type+'&val='+val,
        beforeSend:function(html){
            $('.loading-overlay').show();
        },
        success:function(html){
            $('.loading-overlay').hide();
            $('#userData').html(html);
        }
    }); */
}
 
</script>


<script type="text/javascript">
var save_method; //for save method string

function add_new_data()
{
	save_method = 'Insert';
    $('#user_form')[0].reset(); // reset form on modals
    $('#modal_form_data').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Data'); // Set Title to Bootstrap modal title
}
</script>

<script type="text/javascript">
$(document).on('click', '.update', function(){
	  
   var user_id = $(this).attr("id");
   save_method = 'Edit';
   $('#user_form')[0].reset(); // reset form on modals
   
   var action = "Fetch Single Data";
   $.ajax({
    url:"action.php",
    method:"POST",
    data:{user_id:user_id, action:action},
    dataType:"json",
    success:function(data)
    {

     $('#first_name').val(data.first_name);
     $('#last_name').val(data.last_name);
	 
	 $('#modal_form_data').modal('show'); // show bootstrap modal when complete loaded
	 $('.modal-title').text('Edit Data'); // Set title to Bootstrap modal title
	 
     $('#user_id').val(user_id);
    }
   });
});
</script>


<script type="text/javascript">
function saveData()
{
	
	   
	var formData = new FormData($("#user_form")[0]);	
	formData.append("action", save_method);
		
	var firstName = $('#first_name').val();
	var lastName = $('#last_name').val();
	
   if(firstName != '' && lastName != '')
   {
	   
		$.ajax({
			
			 url:"action.php",
			 method:"POST",
			 data:formData,
			 contentType:false,
			 processData:false,
			 success:function(data)
			 {
					swal({						  
						title: 'Record Saved!',						  
						text: "",						 
						type: 'success'						
					});
						load_data();
				 
			  
				  $('#modal_form_data').modal('hide');
				  $('#user_form')[0].reset();
				  load_data(); 
			
			 }
		})
   }
   else
   {
	alert("Both Fields are Required");
   }
		
	
}
</script>


<script type="text/javascript">

   
 

  $(document).on('click', '.pagination_link', function(){
	    
   var page = $(this).attr("id");
    load_data(page);
  
  });

  
  

 
  
$(document).on('click', '.delete', function(){
	
	var user_id = $(this).attr("id");
	var action = "Delete";
	
	swal({	
		title: 'Are you sure?',
		text: 'You will not be able to recover this record!',
		type: 'question',
		showCancelButton: true,		
		confirmButtonColor: '#DD6B55',		
		confirmButtonText: 'Yes, I am sure!',		
		cancelButtonText: "No, cancel it!",	
	}).then(function() {
			
			$.ajax({
				 url:"action.php",
				 method:"POST",
				 data:{user_id:user_id, action:action},
				 success:function(data)
				 {
						swal({						  
							title: 'Data removed!',						  
							text: "",						 
							type: 'success'						
						});
					load_data();
				 }
			});
	
	},function(dismiss) {

	});

});
  
$('#search').keyup(function(){
	
	var query = $('#search').val();
	var action = "Search";
	if(query != '')
	{
		$.ajax({
		 url:"action.php",
		 method:"POST",
		 data:{query:query, action:action},
		 success:function(data)
		 {
		  $('#user_table').html(data);
		 }
		});
	}
	else
	{
		load_data();
	}
});
  

</script>
