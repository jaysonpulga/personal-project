<?php
class Crud
{
	
 public $connect;
 private $host = "localhost";
 private $username = 'root';
 private $password = '';
 private $database = 'dbpdo';

 function __construct()
 {
  $this->database_connect();
 }

 public function database_connect()
 {
  $this->connect = mysqli_connect($this->host, $this->username, $this->password, $this->database);
 }

 public function execute_query($query)
 {
  return mysqli_query($this->connect, $query);
 }

 public function get_data_in_table($query)
 {

	 
  $output = '';
  $result = $this->execute_query($query);
  $output .= '
  <table class="table table-bordered table-striped">
   <tr>
	<th width="10%"></th>
    <th width="35%">First Name</th>
    <th width="35%">Last Name</th>
    <th width="10%">Update</th>
    <th width="10%">Delete</th>
   </tr>
  ';
  if(mysqli_num_rows($result) > 0)
  {
   while($row = mysqli_fetch_object($result))
   {
    $output .= '
    <tr>
	<td>'.$row->id.'</td>
	 <td>'.$row->first_name.'</td>
     <td>'.$row->last_name.'</td>
     <td><button type="button" name="update" id="'.$row->id.'" class="btn btn-success btn-m update">Update</button></td>
     <td><button type="button" name="delete" id="'.$row->id.'" class="btn btn-danger btn-m delete">Delete</button></td>
    </tr>
    ';
	
   }
  }
  else
  {
   $output .= '
    <tr>
     <td colspan="5" align="center">No Data Found</td>
    </tr>
   ';
  }
  $output .= '</table>';
  return $output;
 } 
 
 


	public function make_pagination_link($query, $record_per_page,$page)
	{ 
	  $output = '';
	  $result = $this->execute_query($query);
	  $total_records = mysqli_num_rows($result);
	  $total_pages = ceil($total_records/$record_per_page);
	  for($i=1; $i<=$total_pages; $i++)
	  {
	   
		$active = ($i == $page ? "active" :"");
		$output .= '<span class="pagination_link '.$active.'" style="cursor:pointer; padding:6px; border:1px solid #ccc;" id="'.$i.'">'.$i.'</span>';
		 
	  }
	  return $output;
	}
 
 
 
	public function insert($table,$data)
	{
	
	   if(!empty($data) && is_array($data))
	   {
		   
   
            $columnString = implode(',', array_keys($data));
			$valueString =  implode ("','",$data );
			$query22 = "INSERT INTO ".$table." (".$columnString.") VALUES ('".$valueString."')";
			return $result = $this->execute_query($query22);
			
        }
		else
		{
            return false;
        }
		
	}
	
	public function modify($table,$rows,$conditions = null )
	{
		
	   if(!empty($rows) && is_array($rows))
	   {
			$colvalSet = '';
            $whereSql = '';
            $i = 0;
			foreach($rows as $key=>$val)
			{
                $pre = ($i > 0)?', ':'';
                $colvalSet .= $pre.$key."='".$val."'";
                $i++;
            }
			
			if(!empty($conditions)&& is_array($conditions))
			{
                $whereSql .= ' WHERE ';
                $i = 0;
                foreach($conditions as $key => $value){
                    $pre = ($i > 0)?' AND ':'';
                    $whereSql .= $pre.$key." = '".$value."'";
                    $i++;
                }
            }
							
			$sql = "UPDATE ".$table." SET ".$colvalSet.$whereSql;
			return $result = $this->execute_query($sql);

        }
		else
		{
            return false;
        }
			
	}
	
	public function selectSingle($table,$conditions = null)
    {
		
		$whereSql = '';
        if(!empty($conditions)&& is_array($conditions)){
            $whereSql .= ' WHERE ';
            $i = 0;
            foreach($conditions as $key => $value){
                $pre = ($i > 0)?' AND ':'';
                $whereSql .= $pre.$key." = '".$value."'";
                $i++;
            }
        }
		
		 $sql = "Select * FROM ".$table.$whereSql;
		 $result = $this->execute_query($sql);
		 $row = mysqli_fetch_assoc($result);
	
		return $row;
		 
    }
	
	
	public function delete($table,$conditions)
	{
		
		$whereSql = '';
        if(!empty($conditions)&& is_array($conditions)){
            $whereSql .= ' WHERE ';
            $i = 0;
            foreach($conditions as $key => $value){
                $pre = ($i > 0)?' AND ':'';
                $whereSql .= $pre.$key." = '".$value."'";
                $i++;
            }
        }
		
        $query = "DELETE FROM ".$table.$whereSql;
		$result = $this->execute_query($query);
		return $result;
		
	}
	
	public function Search($table,$conditions)
	{
		
		$whereSql = '';
        if(!empty($conditions)&& is_array($conditions)){
            $whereSql .= ' WHERE ';
            $i = 0;
            foreach($conditions as $key => $value){
                $pre = ($i > 0)?' OR ':'';
                $whereSql .= $pre.$key." LIKE '%".$value."%' ";
                $i++;
            }
        }
		
		$query = "select * FROM ".$table.$whereSql."ORDER BY id DESC ";
		return $this->get_data_in_table($query);
		
	}
	
	
	
	
}
?>