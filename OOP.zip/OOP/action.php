<?php
//action.php
include 'crud.php';
$object = new Crud();
$table = 'users';


if(isset($_POST["action"]))
{
	
	
	
	
	
	
	
	 if($_POST["action"] == "Load")
	 {
		 
		  $record_per_page = 5;
		  $page = '';
		 

		  if(isset($_POST["page"]))
		  {
		   $page = $_POST["page"];
		  }
		  else
		  {
		   $page = 1;
		  }
		  $start_from = ($page - 1) * $record_per_page;
		  
		  
		  if(!empty($_POST["val"]))
		  {
		   $val = $_POST["val"];

		  }
		   else
		  {
		   $val = "DESC";
		  } 
		  
		  

		  echo $object->get_data_in_table("SELECT * FROM users ORDER BY id $val LIMIT $start_from, $record_per_page");
		  echo '<br /><div align="center">';
		  echo $object->make_pagination_link("SELECT * FROM users ORDER by id", $record_per_page, $page);
		  echo '</div><br />';

	 }
 
	 if($_POST["action"] == "Insert")
	 {
		
			$data = array();
			$data['first_name'] = $_POST['first_name'];
			$data['last_name'] = $_POST['last_name'];
		
			$insert = $object->insert($table,$data);
		
			if($insert > 0)
			{
				  echo 'Data Inserted';
			}
			else
			{
				 echo 'Error inserting record';
			}
	 }
 
 
	 if($_POST["action"] == "Fetch Single Data")
	 {
		
		$condition = array('id' => $_POST['user_id']);
		$output  = $object->selectSingle($table,$condition);
		echo json_encode($output);
	 }
 
 

	 if($_POST["action"] == "Edit")
	 { 
	   
		$data = array();
		$data['first_name'] = $_POST['first_name'];
		$data['last_name'] = $_POST['last_name'];
		$condition = array('id' => $_POST['user_id']);
		
		$update = $object->modify($table,$data,$condition);
			
		if($update > 0)
		{
			  echo 'Data updated';
		}
		else
		{
			 echo 'Error updating data';
		}
	 
	 }
 

	 if($_POST["action"] == "Delete")
	 {
		$condition = array('id' => $_POST['user_id']);
		
		$delete = $object->delete($table,$condition);
			
		if($delete > 0)
		{
			  echo 'Data Deleted';
		}
		else
		{
			 echo 'Error deleting data';
		}
		
	 }
	 
	 
 
	 if($_POST["action"] == "Search")
	 {
		
		
		$search = mysqli_real_escape_string($object->connect, $_POST["query"]);
		$condition = array('first_name' => $search, 'last_name' => $search);
		echo $object->Search($table,$condition);

	 
	 }
 
}
?>